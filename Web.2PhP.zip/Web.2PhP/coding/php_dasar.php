<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>PHP Dasar</title>
</head>

<body>
    <h1>Belajar PHP Dasar</h1>
    <?php
    echo "Hello World";
    ?>
</body>

<body>
    <h1>Menggunakan Variable</h1>
    <?php
    $nim = "312110604";
    $nama = 'Flandylan Rui';
    $kelas = 'TI.21.A.1';
    echo "Kelas : " . $kelas . "<br>";
    echo "NIM : " . $nim . "<br>";
    echo "Nama : $nama";
    ?>
</body>

<body>
    <h1>Predevine Variable</h1>
    <?php
    echo 'Selamat Datang ' . $_GET['nama'];
    ?>
</body>

</html>